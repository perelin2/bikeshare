To accomplish the bikeshare project I used the following ressources:

- bikeshare_2.py as template for my program
- the solutions of the practice problems from the Udacity course, for example the mode() function and 
the to_datetime() functions.
- pandas documentation at pandas.pydata.org including some of the tutorials to 
learn more about how to use pandas
- several posts on stackoverflow.com on generators and how to convert them into a DataFrame object.

October 27, 2018
Diana Colombo
